using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Data.SQLite;
using System.Numerics;

namespace SimpleServer
{
    ////TODO: Replace all data structure with sqlite database and relevant libraries.
    /// <summary>
    /// Basically, the data structures seen here were used for testing, but actual data should be stored in a database. Not that the 
    /// basic methods have been implemented, replacing the data structures with a database should be easi(er).
    /// </summary>
    /// 
    /*  INFORMATION FOR COPILOT
     *  The database schematics used in this code are as follows:
     *  Moodle_model_v3.db
     *  \_ users
     *      \_ username (TEXT)
     *      \_ password_hash (TEXT) #This is the SHA256 hash of the password
     *      \_ name (TEXT)          #This is the name of the user
     *      \_ user_type (INT)      #THis is the type of user: 1 = admin, 2 = teacher, 3 = student
     *      \_ degree_id (INT)      #This is the degree that the student is enrolled in
     *  |
     *  \_ sessions
     *      \_ username (TEXT)
     *      \_ token (TEXT)         #This is the session hash: SHA256(username + session_end)
     *      \_ session_end (TEXT)   #This is the time when the session ends
     *  |
     *  \_ degrees                  #This table is used to store the degrees that are available
     *      \_ id (INT)             #This is the degree ID
     *      \_ name (TEXT)          #This is the name of the degree
     *  |
     *  \_ courses                  #This table is used to store the courses that are available
     *      \_ id (INT)             #This is the course ID
     *      \_ code (TEXT)          #This is the course code
     *      \_ name (TEXT)          #This is the name of the course
     *      \_ credits (INT)        #This is the number of credits the course is worth
     *  |
     *  \_ mycourses                #This table is used to store the courses that a user is enrolled in
     *      \_ id (INT)             #This is the ID of the course enrollment (basically a primary key)
     *      \_ user_id (INT)        #This is the ID of the user enrolled in the course
     *      \_ course_id (INT)      #This is the ID of the course
     *  |
     *  \_ approved_degrees         #This table is used to store the degrees that a student of a certain type can enroll in
     *      \_ id (INT)             #This is the ID of the degree approval
     *      \_ degree_id (INT)      #This is the ID of the degree
     *      \_ course_id (INT)      #This is the ID of the course
     *  |
     *  \_ events                   #Items that occur within any given course (depending on ID)
     *      \_ id (INT)             #This is the ID of the event
     *      \_ course_id (INT)      #This is the ID of the course
     *      \_ name (TEXT)          #This is the name of the event
     *      \_ description (TEXT)   #This is the description of the event
     */


    /*public class User
    {
        public string? Username { get; set; }
        public string? PasswordHash { get; set; }
    }*/

    /*public struct UserSession
    {
        public string Username;
        public string SessionHash;
        public DateTime SessionEnd;
    }*/

    public static class UserDatabase
    {
        //The following variable contains the connection string for the sqlite database file.
        public static string connectionString = "Data Source=Moodle_model_v4.db;Version=3;";
        //The following variable contains the time offset for the session end time. This is the time in minutes that the session will be valid for.
        public static int timeOffset = 15;
        /*public static List<User> Users { get; } = new List<User>
            {
                new User { Username = "John", PasswordHash = "a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3" },   //123
                new User { Username = "Jane", PasswordHash = "b3a8e0e1f9ab1bfe3a36f231f676f78bb30a519d2b21e6c530c0eee8ebb4a5d0" },   //456
                new User { Username = "Jack", PasswordHash = "35a9e381b1a27567549b5f8a6f783c167ebf809f1c4d6a9e367240484d8ce281" },   //789
                new User { Username = "Jill", PasswordHash = "bf6aaaab7c143ca12ae448c69fb72bb4cf1b29154b9086a927a0a91ae334cdf7" },   //012
                new User { Username = "Joe", PasswordHash = "da70dfa4d9f95ac979f921e8e623358236313f334afcd06cddf8a5621cf6a1e9" },    //345
                new User { Username = "Jenny", PasswordHash = "cebe3d9d614ba5c19f633566104315854a11353a333bf96f16b5afa0e90abdc4" }   //678
            };*/
        /*public static List<UserSession> Sessions { get; } = new List<UserSession>();*/
        public static bool DoesTokenExist(string token)
        {
            string SQLcommand = "SELECT COUNT(token) FROM sessions WHERE token = '" + token + "'";
            int count = ExecuteSQLInt(SQLcommand);
            if (count == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool IsTokenValid(string token)
        {
            //The existence of the session has been checked, so we can assume that the token exists in the database.
            //The session end time is checked to see if the session is still valid. The end time string has to be converted to a DateTime object.
            string SQLcommand = "SELECT session_end FROM sessions WHERE token = '" + token + "'";
            string sessionEnd = ExecuteSQLString(SQLcommand);
            DateTime sessionEndDateTime = DateTime.Parse(sessionEnd);
            if (DateTime.Now < sessionEndDateTime)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static string? GetUsernameFromToken(string token)
        {
            string SQLcommand = "SELECT username FROM sessions WHERE token = '" + token + "'";
            return ExecuteSQLString(SQLcommand);
        }
        public static string CreateNewSession(string username)
        {
            string newToken = GetSessionHash(username, DateTime.Now.AddMinutes(timeOffset));
            string SQLcommand = "INSERT INTO sessions (username, token, session_end) VALUES ('" + username + "', '" + newToken + "', '" + DateTime.Now.AddMinutes(timeOffset) + "')";
            ExecuteSQLVoid(SQLcommand);
            return newToken;
        }

        public static string GetSessionHash(string username, DateTime sessionEnd)
        {
            string concatenatedString = username + sessionEnd.ToString();
            string sessionHash = ComputeSHA256Hash(concatenatedString);
            return sessionHash;
        }

        public static string ComputeSHA256Hash(string input)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(input));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }
        public static void RemoveSessionByHash(string sessionHash)
        {
            string SQLcommand = "DELETE FROM sessions WHERE token = '" + sessionHash + "'";
            ExecuteSQLVoid(SQLcommand);
        }
        public static string GetTokenOfSessionByUsername(string username)
        {
            string SQLcommand = "SELECT token FROM sessions WHERE username = '" + username + "'";
            return ExecuteSQLString(SQLcommand);
        }
        public static string? AttemptLogin(string username, string password)
        {
            string passwordHash = ComputeSHA256Hash(password);
            string SQLcommand = "SELECT COUNT(username) FROM users WHERE username = '" + username + "' AND password_hash = '" + passwordHash + "'";
            int count = ExecuteSQLInt(SQLcommand);
            if (count == 1)
            {
                return CreateNewSession(username);
            }
            return null;
        }
        //Method for accessing sqlite database file --> receives string (SQL command) as parameter, and executes it.
        public static void ExecuteSQLVoid(string sqlcommand)
        {
            //string connectionString = "Data Source=Moodle_model_v3.db;Version=3;";
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                using (var command = new SQLiteCommand(sqlcommand, connection))
                {
                    command.ExecuteNonQuery();
                }
                connection.Close();
            }
        }
        public static int ExecuteSQLInt(string sqlcommand)
        {
            //string connectionString = "Data Source=Moodle_model_v3.db;Version=3;";
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                using (var command = new SQLiteCommand(sqlcommand, connection))
                {
                    return Convert.ToInt32(command.ExecuteScalar());
                }
                connection.Close();
            }
        }
        //Method for accessing sqlite database file --> receives string (SQL command) as parameter, and returns a string.
        public static string ExecuteSQLString(string sqlcommand)
        {
            //string connectionString = "Data Source=Moodle_model_v3.db;Version=3;";
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                using (var command = new SQLiteCommand(sqlcommand, connection))
                {
                    return command.ExecuteScalar().ToString();
                }
                connection.Close();
            }
        }
        //Method for accessing sqlite database file --> receives string (SQL command) as parameter, and returns a dictionary.
        public static List<Dictionary<string, object>> ExecuteSQLListOfDictionaries(string sqlcommand)
        {
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                using (var command = new SQLiteCommand(sqlcommand, connection))
                {
                    SQLiteDataReader reader = command.ExecuteReader();
                    List<Dictionary<string, object>> result = new List<Dictionary<string, object>>();
                    while (reader.Read())
                    {
                        Dictionary<string, object> row = new Dictionary<string, object>();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            row.Add(reader.GetName(i), reader.GetValue(i));
                        }
                        result.Add(row);
                    }
                    return result;
                }
            }
        }

        //Method for going through login process --> needed as the main code uses it three times,
        //and it would be inefficient to write the same code three times.
        public static void LoginProcess(Dictionary<string, object> requestData, ref string response)
        {
            if (requestData.ContainsKey("data"))
            {

                Dictionary<string, object> data = JsonSerializer.Deserialize<Dictionary<string, object>>(JsonSerializer.Serialize(requestData["data"]));
                if (data.ContainsKey("username") && data.ContainsKey("password"))
                {
                    string username = data["username"].ToString();
                    string password = data["password"].ToString();
                    string token = UserDatabase.AttemptLogin(username, password);
                    if (token != null)
                    {
                        response += " Login successful. Token: " + token;
                    }
                    else
                    {
                        response += " Login failed: incorrect credentials.";
                    }
                }
                else
                {
                    response += " No \"username\" or \"password\" token was provided.";
                }
            }
            else
            {
                response += " No \"data\" token was provided.";
            }
        }
        public static void LoginProcess(Dictionary<string, object> requestData, ref string response, ref Dictionary<string, object> responseJson)
        {
            if (requestData.ContainsKey("data"))
            {

                Dictionary<string, object> data = JsonSerializer.Deserialize<Dictionary<string, object>>(JsonSerializer.Serialize(requestData["data"]));
                if (data.ContainsKey("username") && data.ContainsKey("password"))
                {
                    string username = data["username"].ToString();
                    string password = data["password"].ToString();
                    string token = UserDatabase.AttemptLogin(username, password);
                    if (token != null)
                    {
                        response += " Login successful. Token: " + token;
                        responseJson.Add("token", token);
                    }
                    else
                    {
                        response += " Login failed: incorrect credentials.";
                        responseJson.Add("token", "");
                    }
                }
                else
                {
                    response += " No \"username\" or \"password\" token was provided.";
                    responseJson.Add("token", "");
                }
            }
            else
            {
                response += " No \"data\" token was provided.";
                responseJson.Add("token", "");
            }
        }
        //Method for getting the user type of a user --> returns the user type as an integer.
        public static int GetUserType(string username)
        {
            string SQLcommand = "SELECT user_type FROM users WHERE username = '" + username + "'";
            return ExecuteSQLInt(SQLcommand);
        }
        //Method for getting the degree ID of a user --> returns the degree ID as an integer
        //(returns null if the user is not a student).
        public static int? GetDegreeID(string username)
        {
            int userType = GetUserType(username);
            if (userType == 3)
            {
                string SQLcommand = "SELECT degree_id FROM users WHERE username = '" + username + "'";
                return ExecuteSQLInt(SQLcommand);
            }
            else
            {
                return null;
            }
        }
        //Method for getting a Dictionary of the courses that the student can enroll in -->
        //receives the degree ID as a parameter, and returns a Dictionary of the courses
        //along with all their data. The point is to return every detail, but only for courses
        //the student is eligible to enroll in. (Returning every course detail is important, as
        //this will be displayed on the client side)
        public static List<Dictionary<string, object>> GetCoursesForStudent(int degreeID)
        {
            string SQLcommand = "SELECT c.code, c.name, c.credit FROM courses c JOIN approved_degrees on approved_degrees.course_id=c.id WHERE approved_degrees.degree_id=" + degreeID + " GROUP BY c.code, c.name, c.credit";
            return ExecuteSQLListOfDictionaries(SQLcommand);
        }
        //Method for enrolling a student in a course --> receives the username and course id as parameters.
        //This method returns true if enrollment was successful, otherwise false. The method must check
        //whether student's degree allows enrollment in the course, and whether the student is already
        //enrolled in the course. If the student is not enrolled in the course, the method should enroll
        //the student in the course. If the student has already been enrolled in the course, the method
        //simply returns true (as the student is already enrolled). If the student is not allowed to enroll
        //in the course, the method should return false.
        public static bool EnrollStudentInCourse(string username, int courseID)
        {
            //Check whether the student is already enrolled in the course
            string SQLcommand = "SELECT COUNT(user_id) FROM mycourses WHERE user_id = (SELECT username FROM users WHERE username = '" + username + "') AND course_id = " + courseID;
            int count = ExecuteSQLInt(SQLcommand);
            if (count == 0)
            {
                //Check whether the student is allowed to enroll in the course
                SQLcommand = "SELECT COUNT(approved_degrees.id) FROM approved_degrees WHERE approved_degrees.degree_id = (SELECT degree_id FROM users WHERE username = '" + username + "') AND course_id = " + courseID;
                count = ExecuteSQLInt(SQLcommand);
                if (count == 1)
                {
                    //Enroll the student in the course
                    SQLcommand = "INSERT INTO mycourses (user_id, course_id) VALUES ((SELECT username FROM users WHERE username = '" + username + "'), " + courseID + ")";
                    ExecuteSQLVoid(SQLcommand);
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return true;
            }
        }
        //Method for getting the courses that a student is enrolled in --> receives the username as a parameter,
        //and returns a List of Dictionaries of the courses that the student is enrolled in. The method should
        //return every detail of the course, as this will be displayed on the client side.
        public static List<Dictionary<string, object>> GetCoursesForStudent(string username)
        {
            string SQLcommand = "SELECT c.code, c.name, c.credit FROM courses c JOIN mycourses on mycourses.course_id=c.id WHERE mycourses.user_id=(SELECT username FROM users WHERE username = '" + username + "') GROUP BY c.code, c.name, c.credit";
            return ExecuteSQLListOfDictionaries(SQLcommand);
        }
        //Get courseID by course code
        public static int GetCourseIDByCode(string courseCode)
        {
            string SQLcommand = "SELECT id FROM courses WHERE code = '" + courseCode + "'";
            return ExecuteSQLInt(SQLcommand);
        }
        public static void GetCoursesForStudent(string username, ref string response, ref Dictionary<string, object> responseJson)
        {
            // Check whether the user is a student
            if (UserDatabase.GetUserType(username) == 3)
            {
                // Get the degree ID of the student
                int? degreeID = UserDatabase.GetDegreeID(username);
                // Check whether the student is enrolled in a degree
                if (degreeID != null)
                {
                    // Get the courses that the student can enroll in
                    List<Dictionary<string, object>> courses = UserDatabase.GetCoursesForStudent((int)degreeID);
                    // Add "courses" to responseJson
                    responseJson.Add("courses", courses);
                }
                else
                {
                    response += " User is not enrolled in a degree.";
                }
            }
            else
            {
                response += " User is not a student.";
            }
        }
        public static void EnrollProcess(Dictionary<string, object> requestData, string username, ref string response, ref Dictionary<string, object> responseJson)
        {
            // Check whether the user is a student
            if (UserDatabase.GetUserType(username) == 3)
            {

                // Get the degree ID of the student
                int? degreeID = UserDatabase.GetDegreeID(username);
                // Check whether the student is enrolled in a degree
                if (degreeID != null)
                {
                    // Check whether the data token is provided
                    if (requestData.ContainsKey("data"))
                    {
                        Dictionary<string, object> data = JsonSerializer.Deserialize<Dictionary<string, object>>(JsonSerializer.Serialize(requestData["data"]));
                        // Check whether the course code token is provided
                        if (data.ContainsKey("course_code"))
                        {
                            string courseCode = data["course_code"].ToString();
                            // Get the course ID of the course
                            int courseID = UserDatabase.GetCourseIDByCode(courseCode);
                            // Check whether the course ID is valid
                            if (courseID != 0)
                            {
                                // Enroll the student in the course
                                if (UserDatabase.EnrollStudentInCourse(username, courseID))
                                {
                                    response += " Student enrolled in course.";
                                }
                                else
                                {
                                    response += " Student not enrolled in course.";
                                }
                            }
                            else
                            {
                                response += " Course code not valid.";
                            }
                        }
                        else
                        {
                            response += " No \"course_code\" token was provided.";
                        }
                    }
                    else
                    {
                        response += " No \"data\" token was provided.";
                    }
                }
                else
                {
                    response += " User is not enrolled in a degree.";
                }
            }
            else
            {
                response += " User is not a student.";
            }
        }
        //Method for creating events for a course --> receives the course code, event name, and event description as parameters.
        //Events can only br created by teachers or admins.
        public static void CreateEvent(string token, string courseCode, string eventName, string eventDescription)
        {
            //Check whether the user is a teacher or an admin
            string username = GetUsernameFromToken(token);
            int userType = GetUserType(username);
            if (userType == 2 || userType == 1)
            {
                //Get the course ID of the course
                int courseID = GetCourseIDByCode(courseCode);
                //Check whether the course ID is valid
                if (courseID != 0)
                {
                    //Create the event
                    string SQLcommand = "INSERT INTO events (course_id, name, description) VALUES (" + courseID + ", '" + eventName + "', '" + eventDescription + "')";
                    ExecuteSQLVoid(SQLcommand);
                }
            }


        }
        //Method for creating users --> receives the username, password, name, and user type as parameters.
        //Can only be done by admins.
        public static void CreateUser(string token, string username, string password, string name, int userType)
        {
            //Check whether the user is an admin
            string adminUsername = GetUsernameFromToken(token);
            int adminUserType = GetUserType(adminUsername);
            if (adminUserType == 1)
            {
                //Create the user
                string passwordHash = ComputeSHA256Hash(password);
                string SQLcommand = "INSERT INTO users (username, password_hash, name, user_type) VALUES ('" + username + "', '" + passwordHash + "', '" + name + "', " + userType + ")";
                ExecuteSQLVoid(SQLcommand);
            }
        }
        //Method for listing all users --> can only be done by admins.
        public static List<Dictionary<string, object>> ListUsers(string token)
        {
            //Check whether the user is an admin
            string username = GetUsernameFromToken(token);
            int userType = GetUserType(username);
            if (userType == 1)
            {
                //List all users
                string SQLcommand = "SELECT username, name, user_type FROM users";
                return ExecuteSQLListOfDictionaries(SQLcommand);
            }
            else
            {
                return new List<Dictionary<string, object>>();
            }
        }
    }

    public class Startup
    {
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors(options =>
            {
                options.AddPolicy("AllowAll",
                    builder => builder
                        .AllowAnyOrigin()
                        .AllowAnyMethod()
                        .AllowAnyHeader());
            });
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseCors("AllowAll");

            app.UseStaticFiles(); // Serve static files (HTML, JS)

            //Beginning of method for handling HTTP requests
            app.Run(async context =>
            {
                string response = "";
                //Declare a JSON object to store the response data (both the string and the JSON
                //object will be sent back to the client)
                Dictionary<string, object> responseJson = new Dictionary<string, object>();


                // Read the request body
                string requestBody = null;
                using (var reader = new System.IO.StreamReader(context.Request.Body, Encoding.UTF8))
                {
                    requestBody = await reader.ReadToEndAsync();
                }

                // Deserialize the JSON into a dictionary
                Console.WriteLine("Request body: " + requestBody + "|");
                Dictionary<string, object>? requestData = null;
                if (requestBody != null && requestBody != "")
                {
                    requestData = JsonSerializer.Deserialize<Dictionary<string, object>>(requestBody);
                }

                //Check whether token is provided by client
                if (requestData != null && requestData.ContainsKey("token") && requestData["token"].ToString() != "")
                {
                    response = "Token provided. ";
                    string token = requestData["token"].ToString();
                    //Check whether the token exists in the database
                    if (UserDatabase.DoesTokenExist(token))
                    {
                        response += "Token exists. ";
                        //Check whether the token is still valid
                        if (UserDatabase.IsTokenValid(token))
                        {
                            response += "Token is valid. ";
                            string username = UserDatabase.GetUsernameFromToken(token);
                            response += "Username: " + username;
                            //create new token for user, and delete old token
                            string newToken = UserDatabase.CreateNewSession(username);
                            UserDatabase.RemoveSessionByHash(token);
                            token = newToken;
                            response += " New token: " + token + " ";
                            //Check whether a "command" token is provided. If so, store command in variable.
                            if (requestData.ContainsKey("command") && requestData["command"].ToString() != "")
                            {
                                string command = requestData["command"].ToString();
                                response += " Command: " + command;

                                ////TODO: Add more commands here
                                //Check whether the command is "logout"
                                if (command == "logout")
                                {
                                    //Delete the session from the database
                                    UserDatabase.RemoveSessionByHash(token);
                                    response += " Session deleted.";
                                }
                                //Check whether the command is "get_courses"
                                else if (command == "get_courses")
                                {
                                    UserDatabase.GetCoursesForStudent(username, ref response, ref responseJson);
                                }
                                //Check whether command is enroll. The data received is the course code, not course ID
                                else if (command == "enroll")
                                {
                                    UserDatabase.EnrollProcess(requestData, username, ref response, ref responseJson);
                                }
                                //Check if the command is "get_my_courses"
                                else if (command == "get_my_courses")
                                {
                                    // Check whether the user is a student
                                    if (UserDatabase.GetUserType(username) == 3)
                                    {
                                        // Get the courses that the student is enrolled in
                                        List<Dictionary<string, object>> courses = UserDatabase.GetCoursesForStudent(username);
                                        // Add "courses" to responseJson
                                        responseJson.Add("courses", courses);
                                    }
                                    else
                                    {
                                        response += " User is not a student.";
                                    }
                                }
                                else if (command == "create_event")
                                {
                                    if (requestData["data"] != null)
                                    {
                                        Dictionary<string, object> data = JsonSerializer.Deserialize<Dictionary<string, object>>(JsonSerializer.Serialize(requestData["data"]));
                                        if (data.ContainsKey("course_code") && data.ContainsKey("event_name") && data.ContainsKey("event_description"))
                                        {
                                            UserDatabase.CreateEvent(token, data["course_code"].ToString(), data["event_name"].ToString(), data["event_description"].ToString());
                                            response += " Event created.";
                                        }
                                        else
                                        {
                                            response += " No \"course_code\", \"event_name\", or \"event_description\" token was provided.";
                                        }
                                    }
                                    else
                                    {
                                        response += " No \"data\" token was provided.";
                                    }
                                }
                                else if (command == "create_user")
                                {
                                    if (requestData["data"] != null)
                                    {
                                        Dictionary<string, object> data = JsonSerializer.Deserialize<Dictionary<string, object>>(JsonSerializer.Serialize(requestData["data"]));
                                        if (data.ContainsKey("username") && data.ContainsKey("password") && data.ContainsKey("name") && data.ContainsKey("user_type"))
                                        {
                                            //Convert user type to Int32
                                            int tipus = Convert.ToInt32(data["user_type"].ToString());
                                            UserDatabase.CreateUser(token, data["username"].ToString(), data["password"].ToString(), data["name"].ToString(), tipus);
                                            response += " User created.";
                                        }
                                        else
                                        {
                                            response += " No \"username\", \"password\", \"name\", or \"user_type\" token was provided.";
                                        }
                                    }
                                    else
                                    {
                                        response += " No \"data\" token was provided.";
                                    }
                                }
                                else if (command == "list_users")
                                {
                                    List<Dictionary<string, object>> users = UserDatabase.ListUsers(token);
                                    responseJson.Add("users", users);
                                }
                                else
                                {
                                    response += " Command not recognized.";
                                }
                            }

                        }
                        else
                        {
                            response += "Token is invalid. ";
                            //Only acceptable command: login
                            if (requestData != null && requestData.ContainsKey("command") && requestData["command"].ToString() == "login")
                            {
                                UserDatabase.LoginProcess(requestData, ref response, ref responseJson);
                            }
                        }
                    }
                    else
                    {
                        response += "Token does not exist. ";
                        //Only acceptable command: login
                        if (requestData != null && requestData.ContainsKey("command") && requestData["command"].ToString() == "login")
                        {
                            UserDatabase.LoginProcess(requestData, ref response, ref responseJson);
                        }
                    }
                }
                else
                {
                    response = "No \"token\" token was provided.";
                    //Only acceptable command: login
                    if (requestData != null && requestData.ContainsKey("command") && requestData["command"].ToString() == "login")
                    {
                        UserDatabase.LoginProcess(requestData, ref response, ref responseJson);
                    }
                }


                await context.Response.WriteAsync(response);
                await context.Response.WriteAsync(JsonSerializer.Serialize(responseJson));
            });
        }
    }

    public class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });
    }
}
